<template>
    <h1>{{ heading }}</h1>
</template>

<script>
export default {
    data() {
        return {
            heading: "Prototype Vue Component"
        }
    }
}
</script>

<style>
    h1 {
        font-family: Arial, Helvetica, sans-serif;
    }
</style>