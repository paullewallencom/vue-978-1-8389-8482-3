<template>
  <Exercise />
</template>

<script>
import Exercise from './components/Exercise2-04'

export default {
  components: {
    Exercise,
  },
}
</script>

<style lang="scss">
@import 'styles/global';
</style>
