<template>
  <Exercise />
</template>

<script>
import Exercise from './components/Exercise2-03'

export default {
  components: {
    Exercise,
  },
}
</script>
