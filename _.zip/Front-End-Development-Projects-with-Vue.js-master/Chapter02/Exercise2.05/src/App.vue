<template>
  <Exercise />
</template>

<script>
import Exercise from './components/Exercise2-05'

export default {
  components: {
    Exercise,
  },
}
</script>
