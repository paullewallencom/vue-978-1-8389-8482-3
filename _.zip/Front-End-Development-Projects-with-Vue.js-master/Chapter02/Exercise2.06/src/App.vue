<template>
  <Exercise />
</template>

<script>
import Exercise from './components/Exercise2-06'

export default {
  components: {
    Exercise,
  },
}
</script>
