<template>
  <div id="app">
    <TextEditorWithCount />
  </div>
</template>
<script>
import TextEditorWithCount from './components/TextEditorWithCount.vue'

export default {
  components: {
    TextEditorWithCount
  }
}
</script>
