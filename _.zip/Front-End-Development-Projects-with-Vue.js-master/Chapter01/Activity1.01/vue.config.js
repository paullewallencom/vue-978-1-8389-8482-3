// vue.config.js
module.exports = {
  // options...
  devServer: {
    proxy: 'https://jobs.github.com/',
  },
}
