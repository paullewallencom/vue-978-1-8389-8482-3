<template>
  <Exercise />
</template>

<script>
import Exercise from './components/Exercise1-07'

export default {
  components: {
    Exercise,
  },
}
</script>

<style lang="scss">
@import 'styles/global';
</style>
