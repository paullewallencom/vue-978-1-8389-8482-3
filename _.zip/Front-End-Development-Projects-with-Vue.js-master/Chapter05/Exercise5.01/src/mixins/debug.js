export default {
  methods: {
    debug(obj) {
      return JSON.stringify(obj, null, 2)
    }
  }
}
