<template>
  <h3>{{ title }}</h3>
</template>

<script>
export default {
  props: ['title']
}
</script>

<style scoped>
h3 {
  width: 100%;
  font-weight: normal;
}
</style>
