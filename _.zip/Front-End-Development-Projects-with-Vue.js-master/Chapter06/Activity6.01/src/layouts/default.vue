<template>
  <div class="default">
    <h1>Messages section</h1>
    <main>
      <slot/>
    </main>
  </div>
</template>